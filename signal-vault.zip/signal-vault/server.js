'use strict';
// Signal Vault — serveur sans dépendance externe (Node.js 22+)
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const PUBLIC_DIR = path.join(__dirname, 'public');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const CONFIG = {
  natcash: process.env.NATCASH || '+509 55 40 60 74',
  moncash: process.env.MONCASH || '+509 36 47 75 11',
  currency: 'gourdes',
  plans: {
    '15': { days: 15, amount: 2000, label: '15 jours' },
    '30': { days: 30, amount: 5000, label: '30 jours' },
  },
  refundHours: 48,
  markets: ['crypto', 'forex', 'actions'],
};

const db = new DatabaseSync(path.join(DATA_DIR, 'signalvault.db'));
db.exec(`
PRAGMA journal_mode = WAL;
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
  pass_hash TEXT NOT NULL, salt TEXT NOT NULL, market TEXT NOT NULL DEFAULT 'crypto',
  role TEXT NOT NULL DEFAULT 'user', blocked INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(
  token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS payments(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, plan TEXT NOT NULL, amount INTEGER NOT NULL,
  method TEXT NOT NULL, file TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
  created_at INTEGER NOT NULL, decided_at INTEGER);
CREATE TABLE IF NOT EXISTS keys(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, payment_id INTEGER NOT NULL, key TEXT NOT NULL UNIQUE,
  days INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'unused', activated_at INTEGER, expires_at INTEGER,
  created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS signals(
  id INTEGER PRIMARY KEY, market TEXT NOT NULL, asset TEXT NOT NULL, direction TEXT NOT NULL,
  entry REAL NOT NULL, tp REAL, sl REAL, status TEXT NOT NULL DEFAULT 'open', note TEXT,
  created_at INTEGER NOT NULL, closed_at INTEGER);
CREATE TABLE IF NOT EXISTS refunds(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, key_id INTEGER NOT NULL, payment_id INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', created_at INTEGER NOT NULL, decided_at INTEGER);
`);

const now = () => Date.now();
const DAY = 86400000;
const q = (sql) => db.prepare(sql);

// ---------- Sécurité ----------
function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}
function verifyPassword(password, user) {
  const a = Buffer.from(hashPassword(password, user.salt), 'hex');
  const b = Buffer.from(user.pass_hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function createUser({ name, phone, email, password, role = 'user' }) {
  const salt = crypto.randomBytes(16).toString('hex');
  const r = q('INSERT INTO users(name,phone,email,pass_hash,salt,role,created_at) VALUES(?,?,?,?,?,?,?)')
    .run(name, phone, email, hashPassword(password, salt), salt, role, now());
  return Number(r.lastInsertRowid);
}
function genKey() {
  const alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  const part = () => Array.from(crypto.randomBytes(4), (b) => alphabet[b % alphabet.length]).join('');
  return `SV-${part()}-${part()}-${part()}`;
}

// Compte administrateur créé au premier démarrage
(function ensureAdmin() {
  const exists = q("SELECT id FROM users WHERE role='admin'").get();
  if (exists) return;
  const email = (process.env.ADMIN_EMAIL || 'admin@signalvault.local').toLowerCase();
  const password = process.env.ADMIN_PASSWORD || crypto.randomBytes(9).toString('base64url');
  createUser({ name: 'Administratrice', phone: '-', email, password, role: 'admin' });
  console.log('\n=== COMPTE ADMINISTRATRICE CRÉÉ ===');
  console.log('Email       :', email);
  console.log('Mot de passe:', password);
  console.log('Notez-le maintenant. Il ne sera plus affiché.\n');
})();

// Limitation des tentatives (anti force brute)
const attempts = new Map();
function tooMany(ip) {
  const a = attempts.get(ip);
  return a && a.count >= 8 && now() - a.first < 10 * 60000;
}
function noteFail(ip) {
  const a = attempts.get(ip);
  if (!a || now() - a.first > 10 * 60000) attempts.set(ip, { count: 1, first: now() });
  else a.count++;
}

// ---------- Utilitaires HTTP ----------
function send(res, status, body, headers = {}) {
  const data = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': typeof body === 'object' && !Buffer.isBuffer(body) ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Cache-Control': 'no-store',
    ...headers,
  });
  res.end(data);
}
const fail = (res, status, message) => send(res, status, { error: message });

function readBody(req, limit = 6 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new Error('too_large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); }
      catch { reject(new Error('bad_json')); }
    });
    req.on('error', reject);
  });
}
function parseCookies(req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach((p) => {
    const i = p.indexOf('=');
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}
function getUser(req) {
  const token = parseCookies(req).sv_token;
  if (!token) return null;
  const s = q('SELECT * FROM sessions WHERE token=?').get(token);
  if (!s || s.expires_at < now()) return null;
  const u = q('SELECT * FROM users WHERE id=?').get(s.user_id);
  if (!u || u.blocked) return null;
  return u;
}
function startSession(res, userId) {
  q('DELETE FROM sessions WHERE user_id=?').run(userId); // une seule session active par compte
  const token = crypto.randomBytes(32).toString('hex');
  q('INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,?)').run(token, userId, now() + 30 * DAY);
  return `sv_token=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${30 * 86400}${process.env.COOKIE_SECURE === '1' ? '; Secure' : ''}`;
}

// ---------- Logique métier ----------
function activeKey(userId) {
  return q("SELECT * FROM keys WHERE user_id=? AND status='active' AND expires_at>? ORDER BY expires_at DESC LIMIT 1").get(userId, now());
}
function publicUser(u) {
  const k = activeKey(u.id);
  const unused = q("SELECT key,days FROM keys WHERE user_id=? AND status='unused' ORDER BY id DESC LIMIT 1").get(u.id);
  const lastPay = q('SELECT id,plan,amount,method,status,created_at FROM payments WHERE user_id=? ORDER BY id DESC LIMIT 1').get(u.id);
  const refund = k ? q('SELECT status FROM refunds WHERE key_id=? ORDER BY id DESC LIMIT 1').get(k.id) : null;
  return {
    id: u.id, name: u.name, email: u.email, phone: u.phone, market: u.market, role: u.role,
    access: !!k,
    key: k ? { key: k.key, expires_at: k.expires_at, activated_at: k.activated_at,
      refund_until: k.activated_at + CONFIG.refundHours * 3600000, refund: refund ? refund.status : null } : null,
    pendingKey: unused ? unused.key : null,
    lastPayment: lastPay || null,
  };
}
function detectImage(buf) {
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8) return 'jpg';
  if (buf.length > 8 && buf.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (buf.length > 12 && buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP') return 'webp';
  return null;
}
const clean = (s, max = 120) => String(s ?? '').trim().slice(0, max);
const num = (v) => (v === '' || v === null || v === undefined ? null : Number(v));

// ---------- Routes ----------
const routes = [];
const route = (method, pattern, opts, handler) => {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:([a-z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ method, re, keys, opts, handler });
};

route('GET', '/api/config', {}, (ctx) => send(ctx.res, 200, {
  natcash: CONFIG.natcash, moncash: CONFIG.moncash, plans: CONFIG.plans, markets: CONFIG.markets, refundHours: CONFIG.refundHours,
}));

route('POST', '/api/register', {}, async (ctx) => {
  const b = ctx.body;
  const name = clean(b.name, 80), phone = clean(b.phone, 30), email = clean(b.email, 120).toLowerCase();
  const password = String(b.password || '');
  if (name.length < 2) return fail(ctx.res, 400, 'Nom invalide.');
  if (!/^[+\d][\d\s-]{6,}$/.test(phone)) return fail(ctx.res, 400, 'Numéro de téléphone invalide.');
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return fail(ctx.res, 400, 'Email invalide.');
  if (password.length < 8) return fail(ctx.res, 400, 'Le mot de passe doit avoir au moins 8 caractères.');
  if (q('SELECT id FROM users WHERE email=?').get(email)) return fail(ctx.res, 409, 'Cet email est déjà utilisé.');
  const id = createUser({ name, phone, email, password });
  const cookie = startSession(ctx.res, id);
  send(ctx.res, 201, { ok: true }, { 'Set-Cookie': cookie });
});

route('POST', '/api/login', {}, async (ctx) => {
  const ip = ctx.req.socket.remoteAddress;
  if (tooMany(ip)) return fail(ctx.res, 429, 'Trop de tentatives. Réessayez dans 10 minutes.');
  const email = clean(ctx.body.email, 120).toLowerCase();
  const u = q('SELECT * FROM users WHERE email=?').get(email);
  if (!u || !verifyPassword(String(ctx.body.password || ''), u)) { noteFail(ip); return fail(ctx.res, 401, 'Email ou mot de passe incorrect.'); }
  if (u.blocked) return fail(ctx.res, 403, 'Ce compte est bloqué. Contactez l’administratrice.');
  const cookie = startSession(ctx.res, u.id);
  send(ctx.res, 200, { ok: true, role: u.role }, { 'Set-Cookie': cookie });
});

route('POST', '/api/logout', { auth: true }, (ctx) => {
  q('DELETE FROM sessions WHERE user_id=?').run(ctx.user.id);
  send(ctx.res, 200, { ok: true }, { 'Set-Cookie': 'sv_token=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' });
});

route('GET', '/api/me', { auth: true }, (ctx) => send(ctx.res, 200, publicUser(ctx.user)));

route('POST', '/api/market', { auth: true }, (ctx) => {
  const m = clean(ctx.body.market, 20);
  if (!CONFIG.markets.includes(m)) return fail(ctx.res, 400, 'Marché invalide.');
  q('UPDATE users SET market=? WHERE id=?').run(m, ctx.user.id);
  send(ctx.res, 200, { ok: true });
});

route('POST', '/api/payments', { auth: true }, (ctx) => {
  const b = ctx.body;
  const plan = CONFIG.plans[String(b.plan)];
  if (!plan) return fail(ctx.res, 400, 'Offre invalide.');
  const method = b.method === 'natcash' ? 'NatCash' : b.method === 'moncash' ? 'MonCash' : null;
  if (!method) return fail(ctx.res, 400, 'Choisissez NatCash ou MonCash.');
  const pending = q("SELECT id FROM payments WHERE user_id=? AND status='pending'").get(ctx.user.id);
  if (pending) return fail(ctx.res, 409, 'Vous avez déjà un paiement en attente de vérification.');
  const m = /^data:image\/(png|jpe?g|webp);base64,(.+)$/.exec(String(b.screenshot || ''));
  if (!m) return fail(ctx.res, 400, 'Capture d’écran invalide (PNG, JPG ou WEBP).');
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > 4 * 1024 * 1024) return fail(ctx.res, 413, 'Image trop lourde (max 4 Mo).');
  const ext = detectImage(buf);
  if (!ext) return fail(ctx.res, 400, 'Le fichier n’est pas une image valide.');
  const file = crypto.randomBytes(16).toString('hex') + '.' + ext;
  fs.writeFileSync(path.join(UPLOAD_DIR, file), buf);
  q('INSERT INTO payments(user_id,plan,amount,method,file,created_at) VALUES(?,?,?,?,?,?)')
    .run(ctx.user.id, String(b.plan), plan.amount, method, file, now());
  send(ctx.res, 201, { ok: true });
});

route('GET', '/api/payments', { auth: true }, (ctx) => {
  send(ctx.res, 200, q('SELECT id,plan,amount,method,status,created_at FROM payments WHERE user_id=? ORDER BY id DESC').all(ctx.user.id));
});

route('POST', '/api/activate', { auth: true }, (ctx) => {
  const key = clean(ctx.body.key, 30).toUpperCase();
  const k = q('SELECT * FROM keys WHERE key=?').get(key);
  if (!k || k.user_id !== ctx.user.id) return fail(ctx.res, 403, 'Clé non valide pour ce compte.');
  if (k.status === 'active') return fail(ctx.res, 409, 'Cette clé est déjà activée.');
  if (k.status !== 'unused') return fail(ctx.res, 410, 'Cette clé n’est plus utilisable.');
  if (activeKey(ctx.user.id)) return fail(ctx.res, 409, 'Vous avez déjà un abonnement actif. Attendez son expiration pour activer la prochaine clé.');
  const t = now();
  q("UPDATE keys SET status='active', activated_at=?, expires_at=? WHERE id=?").run(t, t + k.days * DAY, k.id);
  send(ctx.res, 200, { ok: true });
});

route('GET', '/api/signals', { auth: true }, (ctx) => {
  if (ctx.user.role !== 'admin' && !activeKey(ctx.user.id)) return fail(ctx.res, 402, 'Abonnement requis.');
  const rows = q("SELECT id,market,asset,direction,entry,tp,sl,status,note,created_at,closed_at FROM signals WHERE market=? ORDER BY id DESC LIMIT 100").all(ctx.user.market);
  send(ctx.res, 200, rows);
});

route('GET', '/api/performance', {}, (ctx) => {
  const s = q(`SELECT COUNT(*) total,
    SUM(status='win') wins, SUM(status='loss') losses, SUM(status='open') open FROM signals`).get();
  const closed = (s.wins || 0) + (s.losses || 0);
  const byMarket = q(`SELECT market, SUM(status='win') wins, SUM(status='loss') losses FROM signals GROUP BY market`).all();
  const recent = q("SELECT asset,market,direction,entry,tp,sl,status,created_at,closed_at FROM signals WHERE status IN ('win','loss') ORDER BY closed_at DESC LIMIT 50").all();
  send(ctx.res, 200, { wins: s.wins || 0, losses: s.losses || 0, open: s.open || 0, rate: closed ? Math.round(((s.wins || 0) / closed) * 1000) / 10 : null, byMarket, recent });
});

route('GET', '/api/payments/:id/screenshot', { auth: true }, (ctx) => {
  const p = q('SELECT * FROM payments WHERE id=?').get(Number(ctx.params.id));
  if (!p || (p.user_id !== ctx.user.id && ctx.user.role !== 'admin')) return fail(ctx.res, 404, 'Introuvable.');
  const file = path.join(UPLOAD_DIR, path.basename(p.file));
  if (!fs.existsSync(file)) return fail(ctx.res, 404, 'Fichier manquant.');
  const ext = path.extname(file).slice(1);
  const type = ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : 'image/jpeg';
  ctx.res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff' });
  fs.createReadStream(file).pipe(ctx.res);
});

route('POST', '/api/refund', { auth: true }, (ctx) => {
  const k = activeKey(ctx.user.id);
  if (!k) return fail(ctx.res, 400, 'Aucun abonnement actif.');
  if (now() > k.activated_at + CONFIG.refundHours * 3600000) return fail(ctx.res, 400, `Le délai de ${CONFIG.refundHours} h est dépassé.`);
  if (q("SELECT id FROM refunds WHERE key_id=? AND status IN ('pending','approved')").get(k.id)) return fail(ctx.res, 409, 'Une demande existe déjà.');
  q('INSERT INTO refunds(user_id,key_id,payment_id,created_at) VALUES(?,?,?,?)').run(ctx.user.id, k.id, k.payment_id, now());
  send(ctx.res, 201, { ok: true });
});

// ----- Admin -----
const A = { auth: true, admin: true };

route('GET', '/api/admin/overview', A, (ctx) => {
  send(ctx.res, 200, {
    pendingPayments: q("SELECT COUNT(*) c FROM payments WHERE status='pending'").get().c,
    pendingRefunds: q("SELECT COUNT(*) c FROM refunds WHERE status='pending'").get().c,
    activeSubscribers: q("SELECT COUNT(DISTINCT user_id) c FROM keys WHERE status='active' AND expires_at>?").get(now()).c,
    users: q("SELECT COUNT(*) c FROM users WHERE role='user'").get().c,
  });
});

route('GET', '/api/admin/payments', A, (ctx) => {
  const status = ctx.url.searchParams.get('status');
  const sql = `SELECT p.id,p.plan,p.amount,p.method,p.status,p.created_at,u.name,u.phone,u.email
    FROM payments p JOIN users u ON u.id=p.user_id ${status ? 'WHERE p.status=?' : ''} ORDER BY p.id DESC LIMIT 200`;
  send(ctx.res, 200, status ? q(sql).all(status) : q(sql).all());
});

route('POST', '/api/admin/payments/:id/approve', A, (ctx) => {
  const p = q('SELECT * FROM payments WHERE id=?').get(Number(ctx.params.id));
  if (!p) return fail(ctx.res, 404, 'Introuvable.');
  if (p.status !== 'pending') return fail(ctx.res, 409, 'Déjà traité.');
  const plan = CONFIG.plans[p.plan];
  const key = genKey();
  q("UPDATE payments SET status='approved', decided_at=? WHERE id=?").run(now(), p.id);
  q('INSERT INTO keys(user_id,payment_id,key,days,created_at) VALUES(?,?,?,?,?)').run(p.user_id, p.id, key, plan.days, now());
  send(ctx.res, 200, { ok: true, key });
});

route('POST', '/api/admin/payments/:id/refuse', A, (ctx) => {
  const p = q('SELECT * FROM payments WHERE id=?').get(Number(ctx.params.id));
  if (!p) return fail(ctx.res, 404, 'Introuvable.');
  if (p.status !== 'pending') return fail(ctx.res, 409, 'Déjà traité.');
  q("UPDATE payments SET status='refused', decided_at=? WHERE id=?").run(now(), p.id);
  send(ctx.res, 200, { ok: true });
});

route('GET', '/api/admin/users', A, (ctx) => {
  const users = q("SELECT id,name,phone,email,market,blocked,created_at FROM users WHERE role='user' ORDER BY id DESC").all();
  users.forEach((u) => {
    const k = q("SELECT key,status,expires_at FROM keys WHERE user_id=? AND status IN ('active','unused') ORDER BY id DESC LIMIT 1").get(u.id);
    u.key = k ? k.key : null; u.key_status = k ? k.status : null; u.expires_at = k && k.status === 'active' ? k.expires_at : null;
  });
  send(ctx.res, 200, users);
});

route('POST', '/api/admin/users/:id/block', A, (ctx) => {
  q("UPDATE users SET blocked=1 WHERE id=? AND role='user'").run(Number(ctx.params.id));
  q('DELETE FROM sessions WHERE user_id=?').run(Number(ctx.params.id));
  send(ctx.res, 200, { ok: true });
});
route('POST', '/api/admin/users/:id/unblock', A, (ctx) => {
  q("UPDATE users SET blocked=0 WHERE id=? AND role='user'").run(Number(ctx.params.id));
  send(ctx.res, 200, { ok: true });
});
route('POST', '/api/admin/users/:id/extend', A, (ctx) => {
  const days = Math.min(Math.max(parseInt(ctx.body.days, 10) || 0, 1), 365);
  const k = activeKey(Number(ctx.params.id));
  if (!k) return fail(ctx.res, 400, 'Cet utilisateur n’a pas d’abonnement actif.');
  q('UPDATE keys SET expires_at=expires_at+? WHERE id=?').run(days * DAY, k.id);
  send(ctx.res, 200, { ok: true });
});
route('POST', '/api/admin/users/:id/revoke', A, (ctx) => {
  q("UPDATE keys SET status='revoked' WHERE user_id=? AND status IN ('active','unused')").run(Number(ctx.params.id));
  send(ctx.res, 200, { ok: true });
});

function signalFields(b) {
  const market = clean(b.market, 20), asset = clean(b.asset, 30).toUpperCase();
  const direction = b.direction === 'SELL' ? 'SELL' : b.direction === 'BUY' ? 'BUY' : null;
  const entry = num(b.entry), tp = num(b.tp), sl = num(b.sl);
  if (!CONFIG.markets.includes(market)) return { error: 'Marché invalide.' };
  if (!asset) return { error: 'Actif requis.' };
  if (!direction) return { error: 'Direction invalide.' };
  if (entry === null || !Number.isFinite(entry)) return { error: 'Prix d’entrée invalide.' };
  if ((tp !== null && !Number.isFinite(tp)) || (sl !== null && !Number.isFinite(sl))) return { error: 'TP/SL invalide.' };
  return { market, asset, direction, entry, tp, sl, note: clean(b.note, 200) };
}
route('GET', '/api/admin/signals', A, (ctx) => send(ctx.res, 200, q('SELECT * FROM signals ORDER BY id DESC LIMIT 200').all()));
route('POST', '/api/admin/signals', A, (ctx) => {
  const f = signalFields(ctx.body);
  if (f.error) return fail(ctx.res, 400, f.error);
  q('INSERT INTO signals(market,asset,direction,entry,tp,sl,note,created_at) VALUES(?,?,?,?,?,?,?,?)')
    .run(f.market, f.asset, f.direction, f.entry, f.tp, f.sl, f.note, now());
  send(ctx.res, 201, { ok: true });
});
route('PUT', '/api/admin/signals/:id', A, (ctx) => {
  const id = Number(ctx.params.id);
  const s = q('SELECT * FROM signals WHERE id=?').get(id);
  if (!s) return fail(ctx.res, 404, 'Introuvable.');
  if (ctx.body.status && ['open', 'win', 'loss'].includes(ctx.body.status) && Object.keys(ctx.body).length === 1) {
    q('UPDATE signals SET status=?, closed_at=? WHERE id=?').run(ctx.body.status, ctx.body.status === 'open' ? null : now(), id);
    return send(ctx.res, 200, { ok: true });
  }
  const f = signalFields({ ...s, ...ctx.body });
  if (f.error) return fail(ctx.res, 400, f.error);
  q('UPDATE signals SET market=?,asset=?,direction=?,entry=?,tp=?,sl=?,note=? WHERE id=?').run(f.market, f.asset, f.direction, f.entry, f.tp, f.sl, f.note, id);
  send(ctx.res, 200, { ok: true });
});
route('DELETE', '/api/admin/signals/:id', A, (ctx) => {
  q('DELETE FROM signals WHERE id=?').run(Number(ctx.params.id));
  send(ctx.res, 200, { ok: true });
});

route('GET', '/api/admin/refunds', A, (ctx) => {
  send(ctx.res, 200, q(`SELECT r.id,r.status,r.created_at,r.payment_id,u.name,u.phone,u.email,p.amount,p.method
    FROM refunds r JOIN users u ON u.id=r.user_id JOIN payments p ON p.id=r.payment_id ORDER BY r.id DESC LIMIT 100`).all());
});
route('POST', '/api/admin/refunds/:id/approve', A, (ctx) => {
  const r = q('SELECT * FROM refunds WHERE id=?').get(Number(ctx.params.id));
  if (!r || r.status !== 'pending') return fail(ctx.res, 409, 'Demande introuvable ou déjà traitée.');
  q("UPDATE refunds SET status='approved', decided_at=? WHERE id=?").run(now(), r.id);
  q("UPDATE keys SET status='refunded' WHERE id=?").run(r.key_id);
  send(ctx.res, 200, { ok: true });
});
route('POST', '/api/admin/refunds/:id/refuse', A, (ctx) => {
  q("UPDATE refunds SET status='refused', decided_at=? WHERE id=? AND status='pending'").run(now(), Number(ctx.params.id));
  send(ctx.res, 200, { ok: true });
});

// ---------- Fichiers statiques ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json' };
function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/') rel = '/index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) return fail(res, 404, 'Page introuvable.');
  res.writeHead(200, {
    'Content-Type': MIME[path.extname(file)] || 'application/octet-stream',
    'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Cache-Control': 'no-cache',
    'Content-Security-Policy': "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'",
  });
  fs.createReadStream(file).pipe(res);
}

// ---------- Serveur ----------
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (!url.pathname.startsWith('/api/')) return serveStatic(req, res, url.pathname);
    for (const r of routes) {
      if (r.method !== req.method) continue;
      const m = r.re.exec(url.pathname);
      if (!m) continue;
      const ctx = { req, res, url, params: {}, body: {}, user: null };
      r.keys.forEach((k, i) => { ctx.params[k] = decodeURIComponent(m[i + 1]); });
      if (r.opts.auth) {
        ctx.user = getUser(req);
        if (!ctx.user) return fail(res, 401, 'Veuillez vous connecter.');
        if (r.opts.admin && ctx.user.role !== 'admin') return fail(res, 403, 'Accès refusé.');
      }
      if (['POST', 'PUT', 'DELETE'].includes(req.method)) {
        if (!(req.headers['content-type'] || '').includes('application/json')) return fail(res, 415, 'Format invalide.');
        ctx.body = await readBody(req);
      }
      return await r.handler(ctx);
    }
    fail(res, 404, 'Route inconnue.');
  } catch (e) {
    if (e.message === 'too_large') return fail(res, 413, 'Requête trop volumineuse.');
    if (e.message === 'bad_json') return fail(res, 400, 'JSON invalide.');
    console.error(e);
    if (!res.headersSent) fail(res, 500, 'Erreur du serveur.');
  }
});

setInterval(() => q('DELETE FROM sessions WHERE expires_at<?').run(now()), 3600000).unref();
server.listen(PORT, () => console.log(`Signal Vault démarré sur http://localhost:${PORT}`));
