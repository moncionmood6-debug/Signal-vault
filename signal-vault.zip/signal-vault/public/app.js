'use strict';
const $ = (s) => document.querySelector(s);
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const app = $('#app'), nav = $('#nav'), logoutBtn = $('#logoutBtn');
const MARKET = { crypto: 'Crypto', forex: 'Forex', actions: 'Actions' };
let cfg = null, me = null, tab = 'signals', shotData = null, plan = '15', method = 'natcash', timer = null;

async function api(path, opts = {}) {
  const r = await fetch(path, {
    method: opts.method || 'GET',
    headers: opts.body ? { 'Content-Type': 'application/json' } : {},
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    credentials: 'same-origin',
  });
  let data = {};
  try { data = await r.json(); } catch {}
  if (!r.ok) { const e = new Error(data.error || 'Erreur.'); e.status = r.status; throw e; }
  return data;
}
const fmtDate = (t) => new Date(t).toLocaleString('fr-FR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
const fmtDay = (t) => new Date(t).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' });
const fmtNum = (n) => (n === null || n === undefined ? '—' : Number(n).toLocaleString('fr-FR', { maximumFractionDigits: 6 }));
function left(t) {
  const ms = t - Date.now();
  if (ms <= 0) return 'expiré';
  const d = Math.floor(ms / 86400000), h = Math.floor((ms % 86400000) / 3600000);
  return d > 0 ? `${d} j ${h} h` : `${h} h ${Math.floor((ms % 3600000) / 60000)} min`;
}
function note(el, text, ok) { el.innerHTML = text ? `<div class="msg ${ok ? 'ok' : 'err'}">${esc(text)}</div>` : ''; }

async function boot() {
  cfg = await api('/api/config');
  try { me = await api('/api/me'); } catch { me = null; }
  if (me && me.role === 'admin') { location.href = '/admin.html'; return; }
  render();
}
function render() {
  clearInterval(timer);
  if (!me) { nav.classList.add('hidden'); logoutBtn.classList.add('hidden'); return renderGuest(); }
  logoutBtn.classList.remove('hidden');
  nav.classList.remove('hidden');
  const tabs = [['signals', 'Signaux'], ['sub', 'Abonnement'], ['perf', 'Performances'], ['account', 'Compte']];
  nav.innerHTML = tabs.map(([k, l]) => `<button data-t="${k}" class="${tab === k ? 'on' : ''}">${l}</button>`).join('');
  nav.querySelectorAll('button').forEach((b) => (b.onclick = () => { tab = b.dataset.t; render(); }));
  ({ signals: renderSignals, sub: renderSub, perf: renderPerf, account: renderAccount })[tab]();
}
logoutBtn.onclick = async () => { await api('/api/logout', { method: 'POST', body: {} }).catch(() => {}); me = null; tab = 'signals'; render(); };

// ---------- Invité ----------
async function renderGuest(mode = 'login') {
  app.innerHTML = `
  <div class="hero"><h1>Sachez quand le marché <span style="color:var(--green)">monte</span> et quand il <span style="color:var(--red)">descend</span>.</h1>
  <p>Signaux de trading crypto, forex et actions. Abonnement de 15 ou 30 jours.</p></div>
  <div class="card" id="authCard"></div>
  <div class="card" id="perfCard"><h2>Performances</h2><p class="muted">Chargement…</p></div>
  <p class="warn">Le trading comporte des risques de perte. Les signaux ne sont pas des conseils financiers et ne garantissent aucun gain.</p>`;
  const c = $('#authCard');
  const isLogin = mode === 'login';
  c.innerHTML = `<h2>${isLogin ? 'Connexion' : 'Créer mon compte'}</h2>
    <form id="f">
      ${isLogin ? '' : '<label>Nom complet</label><input name="name" autocomplete="name" required><label>Numéro de téléphone</label><input name="phone" type="tel" autocomplete="tel" placeholder="+509…" required>'}
      <label>Email</label><input name="email" type="email" autocomplete="email" required>
      <label>Mot de passe${isLogin ? '' : ' (8 caractères minimum)'}</label><input name="password" type="password" autocomplete="${isLogin ? 'current-password' : 'new-password'}" required>
      <div id="m"></div>
      <button class="btn" type="submit">${isLogin ? 'Se connecter' : 'S’inscrire'}</button>
    </form>
    <button class="btn ghost" id="sw">${isLogin ? 'Pas de compte ? S’inscrire' : 'J’ai déjà un compte'}</button>`;
  $('#sw').onclick = () => renderGuest(isLogin ? 'register' : 'login');
  $('#f').onsubmit = async (e) => {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(e.target));
    try {
      const r = await api(isLogin ? '/api/login' : '/api/register', { method: 'POST', body });
      if (r.role === 'admin') { location.href = '/admin.html'; return; }
      me = await api('/api/me'); tab = isLogin ? 'signals' : 'sub'; render();
    } catch (err) { note($('#m'), err.message); }
  };
  try { drawPerf($('#perfCard'), await api('/api/performance'), false); } catch {}
}

// ---------- Signaux ----------
async function renderSignals() {
  app.innerHTML = `<div class="card"><h2>Mon marché</h2>
    <div class="row">${cfg.markets.map((m) => `<button class="sm ${me.market === m ? '' : 'ghost'}" data-m="${m}">${MARKET[m]}</button>`).join('')}</div></div>
    <div id="list"></div>`;
  app.querySelectorAll('[data-m]').forEach((b) => (b.onclick = async () => { await api('/api/market', { method: 'POST', body: { market: b.dataset.m } }); me.market = b.dataset.m; renderSignals(); }));
  const list = $('#list');
  if (!me.access) {
    list.innerHTML = `<div class="card"><h2>🔒 Signaux verrouillés</h2><p class="muted">${me.pendingKey ? 'Votre clé est prête : activez-la dans l’onglet Abonnement.' : 'Il vous faut un abonnement actif avec une clé d’accès pour voir les signaux.'}</p>
      <button class="btn" id="go">Aller à l’abonnement</button></div>`;
    $('#go').onclick = () => { tab = 'sub'; render(); };
    return;
  }
  const load = async () => {
    try {
      const rows = await api('/api/signals');
      list.innerHTML = rows.length ? rows.map(sigCard).join('') : `<div class="card"><p class="muted">Aucun signal ${MARKET[me.market]} pour le moment. Revenez bientôt.</p></div>`;
    } catch (e) { list.innerHTML = `<div class="card"><div class="msg err">${esc(e.message)}</div></div>`; }
  };
  await load();
  timer = setInterval(load, 30000);
}
function sigCard(s) {
  return `<div class="sig ${s.direction}">
    <div class="h"><span>${esc(s.asset)}</span><span class="tag ${s.direction}">${s.direction === 'BUY' ? '▲ ACHAT' : '▼ VENTE'}</span></div>
    <div class="grid3"><div><span>Entrée</span>${fmtNum(s.entry)}</div><div><span>Take-profit</span>${fmtNum(s.tp)}</div><div><span>Stop-loss</span>${fmtNum(s.sl)}</div></div>
    <div class="row" style="margin-top:10px;align-items:center"><span class="muted">${fmtDate(s.created_at)}</span>
    <span style="text-align:right"><span class="tag ${s.status}">${{ open: 'En cours', win: 'Gagné', loss: 'Perdu' }[s.status]}</span></span></div>
    ${s.note ? `<p class="muted" style="margin-top:8px">${esc(s.note)}</p>` : ''}</div>`;
}

// ---------- Abonnement ----------
async function renderSub() {
  let html = '';
  if (me.access) {
    const k = me.key;
    const canRefund = Date.now() < k.refund_until && !k.refund;
    html += `<div class="card"><h2>✅ Abonnement actif</h2>
      <p class="muted">Votre clé personnelle</p><div class="keybox">${esc(k.key)}</div>
      <p>Expire le <b>${fmtDay(k.expires_at)}</b> (reste ${left(k.expires_at)}).</p>
      ${k.refund ? `<p class="muted" style="margin-top:8px">Demande de remboursement : <b>${esc({ pending: 'en cours de traitement', approved: 'approuvée', refused: 'refusée' }[k.refund] || k.refund)}</b></p>` : ''}
      ${canRefund ? `<p class="muted" style="margin-top:8px">Garantie 48 h : remboursement possible jusqu’au ${fmtDate(k.refund_until)}.</p><button class="btn red" id="refund">Demander un remboursement</button>` : ''}
      <div id="rm"></div></div>`;
  }
  if (me.pendingKey) {
    html += `<div class="card"><h2>🔑 Votre clé est prête</h2><p class="muted">Paiement validé. Entrez votre clé pour activer l’abonnement (la durée démarre à l’activation).</p>
      <div class="keybox">${esc(me.pendingKey)}</div>
      <form id="act"><label>Collez votre clé</label><input name="key" placeholder="SV-XXXX-XXXX-XXXX" autocapitalize="characters" required><div id="am"></div><button class="btn" type="submit">Activer ma clé</button></form></div>`;
  }
  const lp = me.lastPayment;
  if (lp && lp.status === 'pending') {
    html += `<div class="card"><h2>⏳ Paiement en cours de vérification</h2><p class="muted">Votre capture a été reçue (${esc(lp.method)}, ${fmtNum(lp.amount)} ${cfg.currency}). L’administratrice la vérifie. Votre clé apparaîtra ici dès l’approbation.</p></div>`;
  } else if (!me.access && !me.pendingKey) {
    if (lp && lp.status === 'refused') html += `<div class="card"><div class="msg err">Votre dernier paiement a été refusé. Vérifiez le dépôt et renvoyez une capture claire.</div></div>`;
    html += payForm();
  } else if (me.access && !me.pendingKey) {
    html += `<div class="card"><p class="muted">Pour renouveler, envoyez un nouveau paiement quand votre abonnement approche de sa fin.</p></div>${lp && lp.status === 'pending' ? '' : payForm(true)}`;
  }
  app.innerHTML = html;
  if ($('#refund')) $('#refund').onclick = async () => {
    if (!confirm('Confirmer la demande de remboursement ?')) return;
    try { await api('/api/refund', { method: 'POST', body: {} }); me = await api('/api/me'); renderSub(); } catch (e) { note($('#rm'), e.message); }
  };
  if ($('#act')) $('#act').onsubmit = async (e) => {
    e.preventDefault();
    try { await api('/api/activate', { method: 'POST', body: { key: new FormData(e.target).get('key') } }); me = await api('/api/me'); tab = 'signals'; render(); }
    catch (err) { note($('#am'), err.message); }
  };
  if ($('#pf')) bindPay();
}
function payForm(renew) {
  const p = cfg.plans;
  return `<div class="card"><h2>${renew ? 'Renouveler' : 'Choisir mon abonnement'}</h2>
    <div class="plans">${Object.entries(p).map(([k, v]) => `<div class="plan ${plan === k ? 'on' : ''}" data-p="${k}"><div>${v.label}</div><div class="p">${fmtNum(v.amount)}</div><div class="muted">${cfg.currency}</div></div>`).join('')}</div>
    <h2 style="margin-top:20px">1. Faites le dépôt</h2>
    <p class="muted">Envoyez exactement le montant de l’offre choisie sur l’un de ces numéros.</p>
    <div class="pay"><div><span class="muted">NatCash</span><b>${esc(cfg.natcash)}</b></div><button class="sm ghost" data-copy="${esc(cfg.natcash)}">Copier</button></div>
    <div class="pay"><div><span class="muted">MonCash (Digicel)</span><b>${esc(cfg.moncash)}</b></div><button class="sm ghost" data-copy="${esc(cfg.moncash)}">Copier</button></div>
    <form id="pf"><h2 style="margin-top:20px">2. Envoyez la capture d’écran</h2>
      <label>Moyen utilisé</label><select name="method"><option value="natcash">NatCash</option><option value="moncash">MonCash</option></select>
      <label>Capture du paiement</label><input type="file" id="shot" accept="image/png,image/jpeg,image/webp" required>
      <img id="prev" class="shot hidden" alt="Aperçu">
      <div id="pm"></div><button class="btn" type="submit">Envoyer pour vérification</button></form>
    <p class="muted" style="margin-top:12px">Garantie : remboursement possible pendant ${cfg.refundHours} h après l’activation de votre clé.</p></div>`;
}
function bindPay() {
  app.querySelectorAll('.plan').forEach((el) => (el.onclick = () => { plan = el.dataset.p; app.querySelectorAll('.plan').forEach((x) => x.classList.toggle('on', x === el)); }));
  app.querySelectorAll('[data-copy]').forEach((b) => (b.onclick = async () => {
    try { await navigator.clipboard.writeText(b.dataset.copy.replace(/\s/g, '')); b.textContent = 'Copié ✓'; setTimeout(() => (b.textContent = 'Copier'), 1500); } catch { b.textContent = 'Copie impossible'; }
  }));
  $('#shot').onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    try { shotData = await shrink(f); const img = $('#prev'); img.src = shotData; img.classList.remove('hidden'); } catch { shotData = null; note($('#pm'), 'Image illisible.'); }
  };
  $('#pf').onsubmit = async (e) => {
    e.preventDefault();
    if (!shotData) return note($('#pm'), 'Ajoutez la capture d’écran.');
    const btn = e.target.querySelector('button.btn'); btn.disabled = true; btn.textContent = 'Envoi…';
    try { await api('/api/payments', { method: 'POST', body: { plan, method: new FormData(e.target).get('method'), screenshot: shotData } }); shotData = null; me = await api('/api/me'); renderSub(); }
    catch (err) { note($('#pm'), err.message); btn.disabled = false; btn.textContent = 'Envoyer pour vérification'; }
  };
}
function shrink(file) {
  return new Promise((resolve, reject) => {
    const img = new Image(), url = URL.createObjectURL(file);
    img.onload = () => {
      const s = Math.min(1, 1400 / Math.max(img.width, img.height));
      const c = document.createElement('canvas'); c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url); resolve(c.toDataURL('image/jpeg', 0.85));
    };
    img.onerror = reject; img.src = url;
  });
}

// ---------- Performances ----------
async function renderPerf() {
  app.innerHTML = '<div class="card" id="pc"><p class="muted">Chargement…</p></div>';
  drawPerf($('#pc'), await api('/api/performance'), true);
}
function drawPerf(el, d, full) {
  const closed = d.wins + d.losses;
  el.innerHTML = `<h2>Historique des performances</h2>
    <div class="stats"><div><div class="n g">${d.wins}</div><span class="muted">Gagnants</span></div><div><div class="n r">${d.losses}</div><span class="muted">Perdants</span></div><div><div class="n">${d.rate === null ? '—' : d.rate + '%'}</div><span class="muted">Réussite</span></div></div>
    ${closed ? `<div class="bar"><div style="width:${d.rate}%"></div></div>` : '<p class="muted" style="margin-top:10px">Aucun signal clôturé pour l’instant.</p>'}
    ${full && d.recent.length ? `<div class="scroll" style="margin-top:14px"><table><tr><th>Date</th><th>Actif</th><th>Sens</th><th>Résultat</th></tr>${d.recent.map((r) => `<tr><td>${fmtDate(r.closed_at)}</td><td>${esc(r.asset)}<br><span class="muted">${MARKET[r.market] || ''}</span></td><td><span class="tag ${r.direction}">${r.direction === 'BUY' ? 'Achat' : 'Vente'}</span></td><td><span class="tag ${r.status}">${r.status === 'win' ? 'Gagné' : 'Perdu'}</span></td></tr>`).join('')}</table></div>` : ''}`;
}

// ---------- Compte ----------
function renderAccount() {
  app.innerHTML = `<div class="card"><h2>Mon compte</h2>
    <p><b>${esc(me.name)}</b></p><p class="muted">${esc(me.email)}<br>${esc(me.phone)}</p>
    <p class="muted" style="margin-top:10px">Marché : ${MARKET[me.market]}<br>Abonnement : ${me.access ? 'actif jusqu’au ' + fmtDay(me.key.expires_at) : 'inactif'}</p>
    <p class="muted" style="margin-top:10px">Votre clé et votre compte sont personnels. Une seule connexion à la fois est autorisée.</p></div>`;
}
boot();
