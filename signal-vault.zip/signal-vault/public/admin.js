'use strict';
const $ = (s) => document.querySelector(s);
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const app = $('#app'), nav = $('#nav'), logoutBtn = $('#logoutBtn');
const MARKET = { crypto: 'Crypto', forex: 'Forex', actions: 'Actions' };
let tab = 'payments', ov = null;

async function api(path, opts = {}) {
  const r = await fetch(path, { method: opts.method || 'GET', headers: opts.body ? { 'Content-Type': 'application/json' } : {}, body: opts.body ? JSON.stringify(opts.body) : undefined, credentials: 'same-origin' });
  let d = {}; try { d = await r.json(); } catch {}
  if (!r.ok) { const e = new Error(d.error || 'Erreur.'); e.status = r.status; throw e; }
  return d;
}
const post = (p, body = {}) => api(p, { method: 'POST', body });
const fmtDate = (t) => (t ? new Date(t).toLocaleString('fr-FR', { day: '2-digit', month: 'short', year: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—');
const fmtNum = (n) => (n === null || n === undefined ? '—' : Number(n).toLocaleString('fr-FR', { maximumFractionDigits: 6 }));
const ST = { pending: 'En attente', approved: 'Approuvé', refused: 'Refusé', active: 'Actif', unused: 'Non activée', open: 'En cours', win: 'Gagné', loss: 'Perdu' };
function note(el, text, ok) { el.innerHTML = text ? `<div class="msg ${ok ? 'ok' : 'err'}">${esc(text)}</div>` : ''; }

async function boot() {
  try {
    const me = await api('/api/me');
    if (me.role !== 'admin') { location.href = '/'; return; }
  } catch { return login(); }
  logoutBtn.classList.remove('hidden'); nav.classList.remove('hidden');
  render();
}
function login() {
  logoutBtn.classList.add('hidden'); nav.classList.add('hidden');
  app.innerHTML = `<div class="card" style="margin-top:30px"><h2>Connexion administratrice</h2>
    <form id="f"><label>Email</label><input name="email" type="email" required autocomplete="username"><label>Mot de passe</label><input name="password" type="password" required autocomplete="current-password"><div id="m"></div><button class="btn" type="submit">Entrer</button></form></div>`;
  $('#f').onsubmit = async (e) => {
    e.preventDefault();
    try { const r = await post('/api/login', Object.fromEntries(new FormData(e.target))); if (r.role !== 'admin') { await post('/api/logout'); return note($('#m'), 'Ce compte n’est pas administrateur.'); } boot(); }
    catch (err) { note($('#m'), err.message); }
  };
}
logoutBtn.onclick = async () => { await post('/api/logout').catch(() => {}); login(); };

async function render() {
  ov = await api('/api/admin/overview');
  const tabs = [['payments', `Paiements${ov.pendingPayments ? ' (' + ov.pendingPayments + ')' : ''}`], ['users', 'Abonnés'], ['signals', 'Signaux'], ['refunds', `Remboursements${ov.pendingRefunds ? ' (' + ov.pendingRefunds + ')' : ''}`]];
  nav.innerHTML = tabs.map(([k, l]) => `<button data-t="${k}" class="${tab === k ? 'on' : ''}">${l}</button>`).join('');
  nav.querySelectorAll('button').forEach((b) => (b.onclick = () => { tab = b.dataset.t; render(); }));
  const head = `<div class="card"><div class="stats"><div><div class="n g">${ov.activeSubscribers}</div><span class="muted">Abonnés actifs</span></div><div><div class="n">${ov.users}</div><span class="muted">Inscrits</span></div><div><div class="n r">${ov.pendingPayments}</div><span class="muted">À vérifier</span></div></div></div>`;
  app.innerHTML = head + '<div id="body"></div>';
  ({ payments: viewPayments, users: viewUsers, signals: viewSignals, refunds: viewRefunds })[tab]();
}

async function viewPayments() {
  const rows = await api('/api/admin/payments');
  $('#body').innerHTML = rows.length ? rows.map((p) => `<div class="card">
    <div class="row" style="align-items:center"><b>${esc(p.name)}</b><span style="text-align:right"><span class="tag ${p.status}">${ST[p.status]}</span></span></div>
    <p class="muted">${esc(p.phone)} · ${esc(p.email)}<br>${p.plan} jours · <b style="color:var(--text)">${fmtNum(p.amount)} gourdes</b> · ${esc(p.method)} · ${fmtDate(p.created_at)}</p>
    <button class="sm ghost" style="margin-top:10px" data-shot="${p.id}">Voir la capture</button>
    <div data-img="${p.id}"></div>
    ${p.status === 'pending' ? `<div class="row" style="margin-top:12px"><button class="sm" data-ok="${p.id}">Approuver</button><button class="sm red" data-no="${p.id}">Refuser</button></div>` : ''}
    <div data-m="${p.id}"></div></div>`).join('') : '<div class="card"><p class="muted">Aucun paiement.</p></div>';
  document.querySelectorAll('[data-shot]').forEach((b) => (b.onclick = () => { const box = document.querySelector(`[data-img="${b.dataset.shot}"]`); box.innerHTML = box.innerHTML ? '' : `<img class="shot" src="/api/payments/${b.dataset.shot}/screenshot" alt="Capture">`; }));
  document.querySelectorAll('[data-ok]').forEach((b) => (b.onclick = async () => {
    if (!confirm('Vérifiez que l’argent est bien reçu. Approuver et générer la clé ?')) return;
    try { const r = await post(`/api/admin/payments/${b.dataset.ok}/approve`); await render(); alert('Clé générée : ' + r.key + '\nLe client la voit dans son compte.'); } catch (e) { note(document.querySelector(`[data-m="${b.dataset.ok}"]`), e.message); }
  }));
  document.querySelectorAll('[data-no]').forEach((b) => (b.onclick = async () => { if (!confirm('Refuser ce paiement ?')) return; await post(`/api/admin/payments/${b.dataset.no}/refuse`); render(); }));
}

async function viewUsers() {
  const rows = await api('/api/admin/users');
  $('#body').innerHTML = rows.length ? rows.map((u) => `<div class="card">
    <div class="row" style="align-items:center"><b>${esc(u.name)}</b><span style="text-align:right">${u.blocked ? '<span class="tag refused">Bloqué</span>' : u.key_status ? `<span class="tag ${u.key_status}">${ST[u.key_status]}</span>` : '<span class="tag pending">Sans abonnement</span>'}</span></div>
    <p class="muted">${esc(u.phone)} · ${esc(u.email)}<br>Marché : ${MARKET[u.market]} · Inscrit le ${fmtDate(u.created_at)}<br>${u.key ? 'Clé : ' + esc(u.key) : ''}${u.expires_at ? '<br>Expire le ' + fmtDate(u.expires_at) : ''}</p>
    <div class="row" style="margin-top:10px">
      ${u.blocked ? `<button class="sm" data-a="unblock" data-id="${u.id}">Débloquer</button>` : `<button class="sm red" data-a="block" data-id="${u.id}">Bloquer</button>`}
      ${u.expires_at ? `<button class="sm ghost" data-a="extend" data-id="${u.id}">Prolonger</button>` : ''}
      ${u.key ? `<button class="sm ghost" data-a="revoke" data-id="${u.id}">Retirer la clé</button>` : ''}
    </div></div>`).join('') : '<div class="card"><p class="muted">Aucun abonné pour le moment.</p></div>';
  document.querySelectorAll('[data-a]').forEach((b) => (b.onclick = async () => {
    const a = b.dataset.a, id = b.dataset.id;
    try {
      if (a === 'extend') { const d = prompt('Prolonger de combien de jours ?', '7'); if (!d) return; await post(`/api/admin/users/${id}/extend`, { days: d }); }
      else { if (!confirm('Confirmer ?')) return; await post(`/api/admin/users/${id}/${a}`); }
      render();
    } catch (e) { alert(e.message); }
  }));
}

async function viewSignals() {
  const rows = await api('/api/admin/signals');
  $('#body').innerHTML = `<div class="card"><h2>Publier un signal</h2><form id="sf">
    <div class="row"><div><label>Marché</label><select name="market">${Object.entries(MARKET).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></div>
    <div><label>Actif</label><input name="asset" placeholder="BTC/USDT, EUR/USD, AAPL…" required></div></div>
    <div class="row"><div><label>Direction</label><select name="direction"><option value="BUY">Achat (hausse)</option><option value="SELL">Vente (baisse)</option></select></div>
    <div><label>Prix d’entrée</label><input name="entry" type="number" step="any" required></div></div>
    <div class="row"><div><label>Take-profit</label><input name="tp" type="number" step="any"></div><div><label>Stop-loss</label><input name="sl" type="number" step="any"></div></div>
    <label>Note (optionnel)</label><input name="note" maxlength="200"><div id="sm"></div><button class="btn" type="submit">Publier</button></form></div>
    ${rows.map((s) => `<div class="card"><div class="row" style="align-items:center"><b>${esc(s.asset)} · ${MARKET[s.market]}</b><span style="text-align:right"><span class="tag ${s.direction}">${s.direction === 'BUY' ? 'ACHAT' : 'VENTE'}</span> <span class="tag ${s.status}">${ST[s.status]}</span></span></div>
      <p class="muted">Entrée ${fmtNum(s.entry)} · TP ${fmtNum(s.tp)} · SL ${fmtNum(s.sl)} · ${fmtDate(s.created_at)}${s.note ? '<br>' + esc(s.note) : ''}</p>
      <div class="row" style="margin-top:10px"><button class="sm" data-r="win" data-id="${s.id}">Gagné</button><button class="sm red" data-r="loss" data-id="${s.id}">Perdu</button><button class="sm ghost" data-r="open" data-id="${s.id}">En cours</button><button class="sm ghost" data-del="${s.id}">Supprimer</button></div></div>`).join('')}`;
  $('#sf').onsubmit = async (e) => {
    e.preventDefault();
    try { await post('/api/admin/signals', Object.fromEntries(new FormData(e.target))); viewSignals(); } catch (err) { note($('#sm'), err.message); }
  };
  document.querySelectorAll('[data-r]').forEach((b) => (b.onclick = async () => { await api(`/api/admin/signals/${b.dataset.id}`, { method: 'PUT', body: { status: b.dataset.r } }); viewSignals(); }));
  document.querySelectorAll('[data-del]').forEach((b) => (b.onclick = async () => { if (!confirm('Supprimer ce signal ?')) return; await api(`/api/admin/signals/${b.dataset.del}`, { method: 'DELETE', body: {} }); viewSignals(); }));
}

async function viewRefunds() {
  const rows = await api('/api/admin/refunds');
  $('#body').innerHTML = rows.length ? rows.map((r) => `<div class="card"><div class="row" style="align-items:center"><b>${esc(r.name)}</b><span style="text-align:right"><span class="tag ${r.status}">${ST[r.status]}</span></span></div>
    <p class="muted">${esc(r.phone)} · ${esc(r.email)}<br>À rembourser : <b style="color:var(--text)">${fmtNum(r.amount)} gourdes</b> via ${esc(r.method)} · demandé le ${fmtDate(r.created_at)}</p>
    ${r.status === 'pending' ? `<p class="muted" style="margin-top:6px">En approuvant, l’accès du client est coupé. Envoyez-lui ensuite l’argent par ${esc(r.method)}.</p><div class="row" style="margin-top:10px"><button class="sm" data-a="approve" data-id="${r.id}">Approuver</button><button class="sm red" data-a="refuse" data-id="${r.id}">Refuser</button></div>` : ''}</div>`).join('') : '<div class="card"><p class="muted">Aucune demande de remboursement.</p></div>';
  document.querySelectorAll('[data-a]').forEach((b) => (b.onclick = async () => { if (!confirm('Confirmer ?')) return; try { await post(`/api/admin/refunds/${b.dataset.id}/${b.dataset.a}`); render(); } catch (e) { alert(e.message); } }));
}
boot();
