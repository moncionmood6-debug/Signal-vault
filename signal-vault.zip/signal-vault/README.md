# Signal Vault

Site de signaux de trading (crypto, forex, actions) avec abonnements payés par NatCash / MonCash,
vérification manuelle des captures, clés d'accès personnelles et panneau administrateur.

Aucune dépendance à installer : il faut seulement **Node.js 22.5 ou plus récent**.

## Lancer en local
```
node server.js
```
Ouvrez http://localhost:3000

Au **premier démarrage**, le mot de passe administrateur est affiché dans la console. Notez-le.
Pour choisir le vôtre : `ADMIN_EMAIL=vous@mail.com ADMIN_PASSWORD=MotDePasseSolide node server.js`
(à faire avant le premier démarrage). Panneau admin : `/admin.html`.

## Variables d'environnement (toutes facultatives)
| Variable | Rôle | Défaut |
|---|---|---|
| PORT | Port du serveur | 3000 |
| DATA_DIR | Dossier de la base et des captures | ./data |
| NATCASH / MONCASH | Numéros affichés aux clients | vos numéros actuels |
| ADMIN_EMAIL / ADMIN_PASSWORD | Compte admin créé au 1er démarrage | admin@signalvault.local / aléatoire |
| COOKIE_SECURE | Mettre `1` quand le site est en HTTPS | — |

## Mettre en ligne
Il faut un hébergeur qui exécute Node.js **avec un disque persistant** (VPS, Railway, Render, Fly.io…).
1. Envoyez le dossier, lancez `node server.js` (ou `npm start`).
2. Placez le dossier `DATA_DIR` sur le disque persistant : il contient la base et les captures.
3. Activez le HTTPS (automatique chez la plupart des hébergeurs) puis mettez `COOKIE_SECURE=1`.
4. **Sauvegardez régulièrement le dossier data/** (base `signalvault.db` + `uploads/`).

## Fonctionnement
1. Le client s'inscrit, choisit l'offre (2000 G / 15 j ou 5000 G / 30 j), dépose l'argent sur NatCash ou MonCash et envoie la capture.
2. Vous ouvrez **Admin > Paiements**, regardez la capture, vérifiez la réception de l'argent, puis **Approuver**.
3. Une clé personnelle `SV-XXXX-XXXX-XXXX` est créée pour ce client seulement. Il l'active dans son compte ; la durée démarre à l'activation.
4. Vous publiez les signaux dans **Admin > Signaux** et marquez le résultat (Gagné / Perdu). La page Performances se calcule toute seule.
5. Remboursement : le client peut le demander pendant 48 h après l'activation. Vous approuvez dans **Admin > Remboursements** (l'accès est coupé), puis vous renvoyez l'argent vous-même.

## Protection contre le partage
Clé liée à un seul compte, une seule connexion active par compte (une nouvelle connexion déconnecte l'ancienne),
mots de passe chiffrés (scrypt), limite de tentatives de connexion, captures visibles seulement par le client et l'admin.

## Important
- Les signaux sont **publiés par vous à la main** : l'application n'en génère pas automatiquement.
- Vérifiez les numéros NatCash / MonCash dans server.js ou via les variables avant la mise en ligne.
- Le trading comporte des risques : gardez l'avertissement affiché sur le site et ne promettez aucun gain.

## Hébergement rapide sur Render (Dockerfile + render.yaml inclus)
1. Mettez le dossier sur GitHub (dépôt privé).
2. Sur render.com : New > Blueprint > choisissez le dépôt. Render lit `render.yaml`.
3. Renseignez `ADMIN_EMAIL` et `ADMIN_PASSWORD` quand Render les demande.
4. Le disque persistant (/data) est déjà prévu dans la configuration (offre payante « Starter » requise).
5. Une fois en ligne, ouvrez l'adresse fournie, puis `/admin.html`.

## Icône de l'application
Le logo est installé comme icône du site (favicon, écran d'accueil iPhone/Android). Sur téléphone :
ouvrez le site, menu du navigateur > « Ajouter à l'écran d'accueil ».
